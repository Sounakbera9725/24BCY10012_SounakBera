import os
import csv
from io import StringIO
from functools import wraps
from flask import Flask, request, jsonify, Response
from pymongo import MongoClient, ASCENDING
from pymongo.errors import DuplicateKeyError
from dotenv import load_dotenv

load_dotenv()

MONGO_URI = os.getenv('MONGO_URI', 'mongodb://localhost:27017')
API_KEY = os.getenv('API_KEY', None)

client = MongoClient(MONGO_URI)
db = client['student_db']
students_col = db['students']

# Ensure unique student_id
students_col.create_index([('student_id', ASCENDING)], unique=True)

app = Flask(__name__)


def require_api_key(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if API_KEY is None:
            return f(*args, **kwargs)
        key = request.headers.get('X-API-KEY')
        if not key or key != API_KEY:
            return jsonify({'error': 'Unauthorized'}), 401
        return f(*args, **kwargs)
    return decorated


def normalize_student(doc):
    if not doc:
        return None
    doc['_id'] = str(doc.get('_id'))
    return doc


@app.errorhandler(400)
def bad_request(e):
    return jsonify({'error': 'Bad request', 'message': str(e)}), 400


@app.errorhandler(404)
def not_found(e):
    return jsonify({'error': 'Not found'}), 404


@app.route('/students', methods=['GET'])
@require_api_key
def list_students():
    query = {}
    student_id = request.args.get('student_id')
    name = request.args.get('name')
    department = request.args.get('department')

    if student_id:
        query['student_id'] = student_id
    if name:
        query['name'] = {'$regex': name, '$options': 'i'}
    if department:
        query['department'] = {'$regex': department, '$options': 'i'}

    # pagination & sorting
    try:
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))
    except ValueError:
        return jsonify({'error': 'page and per_page must be integers'}), 400

    sort_by = request.args.get('sort_by', 'student_id')
    sort_order = request.args.get('sort_order', 'asc')
    sort_dir = ASCENDING if sort_order == 'asc' else -1

    cursor = students_col.find(query).sort(sort_by, sort_dir).skip((page - 1) * per_page).limit(per_page)
    docs = list(cursor)
    total = students_col.count_documents(query)
    return jsonify({'items': [normalize_student(d) for d in docs], 'total': total, 'page': page, 'per_page': per_page}), 200


@app.route('/students/<student_id>', methods=['GET'])
@require_api_key
def get_student(student_id):
    doc = students_col.find_one({'student_id': student_id})
    if not doc:
        return jsonify({'error': 'Student not found'}), 404
    return jsonify(normalize_student(doc)), 200


@app.route('/students', methods=['POST'])
@require_api_key
def create_student():
    if not request.is_json:
        return jsonify({'error': 'Expected JSON body'}), 400
    data = request.get_json(force=True)
    required = ['student_id', 'name', 'department']
    if not all(k in data and str(data[k]).strip() for k in required):
        return jsonify({'error': 'Missing fields, required: ' + ','.join(required)}), 400
    student = {
        'student_id': str(data['student_id']).strip(),
        'name': str(data['name']).strip(),
        'department': str(data['department']).strip(),
        'email': data.get('email'),
        'meta': data.get('meta', {})
    }
    try:
        res = students_col.insert_one(student)
    except DuplicateKeyError:
        return jsonify({'error': 'student_id already exists'}), 409
    student['_id'] = str(res.inserted_id)
    return jsonify(student), 201


@app.route('/students/<student_id>', methods=['PUT'])
@require_api_key
def update_student(student_id):
    if not request.is_json:
        return jsonify({'error': 'Expected JSON body'}), 400
    data = request.get_json(force=True)
    updates = {}
    for f in ['name', 'department', 'email', 'meta']:
        if f in data:
            updates[f] = data[f]
    if not updates:
        return jsonify({'error': 'No updatable fields provided'}), 400
    res = students_col.update_one({'student_id': student_id}, {'$set': updates})
    if res.matched_count == 0:
        return jsonify({'error': 'Student not found'}), 404
    doc = students_col.find_one({'student_id': student_id})
    return jsonify(normalize_student(doc)), 200


@app.route('/students/<student_id>', methods=['DELETE'])
@require_api_key
def delete_student(student_id):
    res = students_col.delete_one({'student_id': student_id})
    if res.deleted_count == 0:
        return jsonify({'error': 'Student not found'}), 404
    return jsonify({'status': 'deleted'}), 200


@app.route('/students/import', methods=['POST'])
@require_api_key
def import_students():
    # Accept CSV in body (raw) or multipart file
    csv_data = None
    if 'file' in request.files:
        f = request.files['file']
        csv_data = f.read().decode('utf-8')
    else:
        csv_data = request.get_data(as_text=True)
    if not csv_data:
        return jsonify({'error': 'No CSV data provided'}), 400
    reader = csv.DictReader(StringIO(csv_data))
    inserted = 0
    errors = []
    for i, row in enumerate(reader, start=1):
        if 'student_id' not in row or 'name' not in row or 'department' not in row:
            errors.append({'row': i, 'error': 'Missing required columns'})
            continue
        student = {
            'student_id': row['student_id'].strip(),
            'name': row['name'].strip(),
            'department': row['department'].strip(),
            'email': row.get('email')
        }
        try:
            students_col.insert_one(student)
            inserted += 1
        except Exception as e:
            errors.append({'row': i, 'error': str(e)})
    return jsonify({'inserted': inserted, 'errors': errors}), 200


@app.route('/students/export', methods=['GET'])
@require_api_key
def export_students():
    query = {}
    name = request.args.get('name')
    department = request.args.get('department')
    if name:
        query['name'] = {'$regex': name, '$options': 'i'}
    if department:
        query['department'] = {'$regex': department, '$options': 'i'}
    cursor = students_col.find(query)
    si = StringIO()
    fieldnames = ['student_id', 'name', 'department', 'email']
    writer = csv.DictWriter(si, fieldnames=fieldnames)
    writer.writeheader()
    for d in cursor:
        writer.writerow({k: d.get(k, '') for k in fieldnames})
    output = si.getvalue()
    return Response(output, mimetype='text/csv', headers={"Content-Disposition": "attachment;filename=students.csv"})


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.getenv('PORT', 5000)), debug=os.getenv('FLASK_DEBUG', 'False') == 'True')
