import os
from pymongo import MongoClient

MONGO_URI = os.getenv('MONGO_URI', 'mongodb://localhost:27017')
client = MongoClient(MONGO_URI)
db = client['student_db']
students = db['students']


def prompt_student():
    sid = input('Student ID: ').strip()
    name = input('Name: ').strip()
    dept = input('Department: ').strip()
    email = input('Email: ').strip()
    return {'student_id': sid, 'name': name, 'department': dept, 'email': email}


def create():
    s = prompt_student()
    try:
        students.insert_one(s)
        print('Created', s['student_id'])
    except Exception as e:
        print('Error:', e)


def list_all():
    for doc in students.find():
        print(doc)


def find():
    key = input('Search by student_id/name/department value: ').strip()
    docs = students.find({'$or': [{'student_id': key}, {'name': {'$regex': key, '$options': 'i'}}, {'department': {'$regex': key, '$options': 'i'}}]})
    for d in docs:
        print(d)


def update():
    sid = input('Student ID to update: ').strip()
    doc = students.find_one({'student_id': sid})
    if not doc:
        print('Not found')
        return
    print('Current:', doc)
    name = input('New name (leave blank keep): ').strip()
    dept = input('New department (leave blank keep): ').strip()
    email = input('New email (leave blank keep): ').strip()
    updates = {}
    if name:
        updates['name'] = name
    if dept:
        updates['department'] = dept
    if email:
        updates['email'] = email
    if updates:
        students.update_one({'student_id': sid}, {'$set': updates})
        print('Updated')
    else:
        print('No changes')


def delete():
    sid = input('Student ID to delete: ').strip()
    res = students.delete_one({'student_id': sid})
    if res.deleted_count:
        print('Deleted')
    else:
        print('Not found')


def menu():
    while True:
        print('\nStudent CLI')
        print('1) Create')
        print('2) List all')
        print('3) Search')
        print('4) Update')
        print('5) Delete')
        print('6) Import CSV')
        print('7) Export CSV')
        print('0) Exit')
        c = input('> ').strip()
        if c == '1':
            create()
        elif c == '2':
            list_all()
        elif c == '3':
            find()
        elif c == '4':
            update()
        elif c == '5':
            delete()
        elif c == '6':
            path = input('CSV path to import: ').strip()
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    data = f.read()
                # POST to /students/import expects raw CSV
                from requests import post
                base = os.getenv('BASE_URL', 'http://localhost:5000')
                r = post(base + '/students/import', data=data)
                print('Response', r.status_code, r.text)
            except Exception as e:
                print('Error importing CSV:', e)
        elif c == '7':
            path = input('CSV path to save export: ').strip()
            try:
                from requests import get
                base = os.getenv('BASE_URL', 'http://localhost:5000')
                r = get(base + '/students/export')
                if r.status_code == 200:
                    with open(path, 'w', encoding='utf-8') as f:
                        f.write(r.text)
                    print('Saved to', path)
                else:
                    print('Error', r.status_code, r.text)
            except Exception as e:
                print('Error exporting CSV:', e)
        elif c == '0':
            break
        else:
            print('Unknown')


if __name__ == '__main__':
    menu()
