import os
import time
import requests

BASE = os.getenv('BASE_URL', 'http://127.0.0.1:5000')


def test_crud_cycle():
    s = {'student_id': 'PYTEST1', 'name': 'Py Test', 'department': 'QA', 'email': 'py@test.local'}
    r = requests.post(BASE + '/students', json=s)
    assert r.status_code in (200, 201)
    r = requests.get(BASE + '/students/PYTEST1')
    assert r.status_code == 200
    r = requests.put(BASE + '/students/PYTEST1', json={'name': 'Py Test Updated'})
    assert r.status_code == 200
    r = requests.delete(BASE + '/students/PYTEST1')
    assert r.status_code == 200
