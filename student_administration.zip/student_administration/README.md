# Student Management System (Python + MongoDB)

This project provides:
- A Flask REST API for CRUD operations on student records (I have tested it in Postman also uploaded it).
- A console-based CLI that performs CRUD directly against MongoDB.

Prerequisites
- Python 3.8+ can also run on 3.5 no issues
- MongoDB running locally or a connection string (set `MONGO_URI` env var)

Install
```bash
python -m venv .venv
source .venv/bin/activate   #refer to the python documentation if you are using linux
pip install -r requirements.txt
```

Run the API
```bash
set MONGO_URI=mongodb://localhost:27017   # on PowerShell: $env:MONGO_URI='mongodb://localhost:27017'
python app.py
```
The API listens on port `5000`.

Sample Postman requests
- Create student (POST): `http://localhost:5000/students`
  Body (JSON):
  ```json
  {
    "student_id": "S001",
    "name": "Alice Example",
    "department": "Computer Science",
    "email": "alice@example.com"
  }
  ```
- List students (GET): `http://localhost:5000/students`
- Search by name (GET): `http://localhost:5000/students?name=alice`
- Get by ID (GET): `http://localhost:5000/students/S001`
- Update (PUT): `http://localhost:5000/students/S001` with JSON body of fields to update
- Delete (DELETE): `http://localhost:5000/students/S001`

Use the console CLI
```bash
python cli.py
```

Notes
- The API and CLI use the `student_db` database and `students` collection.
- `student_id` is indexed as unique; creating a student with a duplicate `student_id` returns an error.
 
Additional features implemented
- Pagination, sorting and filtering on `GET /students` via query params: `page`, `per_page`, `sort_by`, `sort_order`.
- CSV import: `POST /students/import` (raw CSV body or multipart file `file`).
- CSV export: `GET /students/export` returns CSV attachment.
- Simple token auth: set `API_KEY` env var and send header `X-API-KEY` on requests.
- Docker support: `Dockerfile` and `docker-compose.yml` to run API + MongoDB.
- Sample data loader: `sample_data.py`.
- Postman collection and environment included: `postman_collection.json`, `postman_environment.json`.
- Curl snippets: `curl_snippets.md`.
- Basic pytest test available in `tests/test_api.py` (expects API running locally).

Running with Docker
```bash
docker-compose up --build
```

Running tests
1. Start the API (locally or via Docker).
2. Run:
```bash
pytest -q
```

Also I have implemented the docker which help me in containerization and will be very much applicable for applications with all their dependencies into standardized units called containers. So it will elimate a major problem which is like-"i can only run it on my laptop only" so to evade this we need to do that.

